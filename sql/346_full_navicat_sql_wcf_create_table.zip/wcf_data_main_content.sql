﻿/*
MySQL Data Transfer
Source Host: localhost
Source Database: wcf
Target Host: localhost
Target Database: wcf
Date: 14.03.2012 16:02:37
*/

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `wcf_panels` VALUES ('1', 'navigation_panel', 'file', '-1', '1', '1', '1', '0');
INSERT INTO `wcf_panels` VALUES ('2', 'user_info_panel', 'file', '-1', '4', '1', '1', '0');
INSERT INTO `wcf_panels` VALUES ('3', 'welcome_message_panel', 'file', '-1', '2', '1', '1', '0');
INSERT INTO `wcf_comments` VALUES ('1', '1', '2012-01-17 18:08:28', '1', '5', '<p><span style=\\\"text-decoration: line-through;\\\"><span style=\\\"text-decoration: underline;\\\"><em><strong>Проверка работаспособности!</strong></em></span></span></p>');
INSERT INTO `wcf_forums` VALUES ('1', '0', '1', 'Информация о сервере', null, '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('2', '0', '2', 'Мир Warcraft', null, '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('3', '0', '3', 'Жалобы', null, '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('4', '0', '4', 'Разное', null, '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('5', '1', '1', 'Информация от администрации', 'Обновления, изменения, события, новости.', '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('6', '1', '2', 'Мастерская', 'Делимся своими идеями, решениями. Обсуждаем, создаем что-то свое. В общем \"Игродельня\".', '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('7', '1', '3', 'Конкурсы форума', 'Проведение массовых мероприятий на территории форума. ', '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('8', '1', '4', 'Техническая поддержка', 'Раздел технической поддержки игроков.', '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('9', '2', '1', 'Классы', 'Обсуждение, описание, предпочтения, возможности, харрактеристики.', '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('10', '2', '2', 'Профессии', 'Обсуждение, описание, предпочтения, возможности, плюсы и минусы.', '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('11', '2', '3', 'Квесты', 'Помощь по квестам в World of Warcraft', '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('12', '2', '4', 'Достижения', 'Обсуждение, описание, помощь.', '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('13', '2', '5', 'PVE: подземелья', 'Раздел для победителей драконов. Здесь делятся советами по прохождению инстансов, приводятся тактики сражения с боссами и публикуются новости об успехах гильдий.', '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('14', '2', '6', 'PVP: арены и поля боя, слава', 'Раздел для гладиаторов и маршалов. Здесь обсуждается PvP во всех его проявлениях и все связанные с ним нюансы: очки чести, аренный рейтинг, PvP сеты и титулы и т.д.', '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('15', '2', '7', 'Аддоны и Макросы', 'Скачиваем и заказываем', '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('16', '3', '1', 'Жалобы', 'Нарушения правил GM/игроками. Обсуждение и критика.', '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('17', '3', '2', 'Жалобы на действия модераторов.', 'Обжалование действий модераторов. ', '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('18', '4', '1', 'ОффТопик', 'Разговоры на любую тему', '0', '0', '0');
INSERT INTO `wcf_forums` VALUES ('19', '4', '2', 'Форум Гильдий', 'Здесь можно обсудить гильдии, и получить персональные разделы.', '0', '0', '0');
INSERT INTO `wcf_navigation_links` VALUES ('1', 'Общее пространство', '---', '-1', '1', '1');
INSERT INTO `wcf_navigation_links` VALUES ('2', 'Главная', 'index.php', '-1', '1', '2');
INSERT INTO `wcf_navigation_links` VALUES ('3', 'Форум', 'forum/index.php', '-1', '1', '3');
INSERT INTO `wcf_navigation_links` VALUES ('4', 'FAQ', 'faq.php', '-1', '1', '4');
INSERT INTO `wcf_news` VALUES ('1', '2012-01-26 15:51:10', '5', 'От разработчика', '1', '1', '<p>wcf успешно установлен и готов к использованию!</p>', '<p>wcf успешно установлен и готов к использованию!</p>', '-1', '1');
INSERT INTO `wcf_news` VALUES ('4', '2012-01-26 15:39:43', '5', 'Десятка умерших аддонов', '1', '1', '<p>Не секрет что Близзард любят заимствовать иде у различного вида проектов. Получается это у них отменно, именно поэтому треть их бюджета уходит на судебные разбирательства. Но вот о внутреннем заимствовании мало кто задумывается. А именно заимствование аддонов, которые пользователи создают за бесплатно и продвигают в массы. Ну а Blizzard берут идею и подгребают под себя с выходом очередного патча.</p>\r\n<p><br /> <strong>Десяток аддонов, пострадавших от инициативы Blizzard:<br /> </strong><br /> <strong><span><strong><strong>QuestHelper</strong></strong></span> </strong>- Самый популярный аддон для The Burning Crusade, и Начальных версий Wrath of the Lich King, но после патча 3.3, про него многие забыли, ибо Blizzard придумали свой \\\\\\\"Квест хелпер\\\\\\\", который понравился многим намного больше аддона. По большей части потому, что он не требовал так много ресурсов от вашей машины...</p>', '<p>Не секрет что Близзард любят заимствовать иде у различного вида проектов. Получается это у них отменно, именно поэтому треть их бюджета уходит на судебные разбирательства. Но вот о внутреннем заимствовании мало кто задумывается. А именно заимствование аддонов, которые пользователи создают за бесплатно и продвигают в массы. Ну а Blizzard берут идею и подгребают под себя с выходом очередного патча. <br /> <strong>Десяток аддонов, пострадавших от инициативы Blizzard:<br /> </strong><br /> <strong>QuestHelper </strong>- Самый популярный аддон для The Burning Crusade, и Начальных версий Wrath of the Lich King, но после патча 3.3, про него многие забыли, ибо Blizzard придумали свой \\\\\\\"Квест хелпер\\\\\\\", который понравился многим намного больше аддона. По большей части потому, что он не требовал так много ресурсов от вашей машины.<br /> <br /> <br /> <strong>Cartographer</strong> - В былое время был популярен не менее чем QuestHelper, ибо с ним вместе они работали на славу и помогали проходить квесты не одному поколению Воверов, но после патча 3.0 Блззард кардинально изменили систему определения локаций, поэтому разработчик прекратил дальнейшую модификацию этого аддона.<br /> <br /> <strong><span>Outfitter </span></strong>- Не каждый мог себе позволить носить при себе сразу два сета, для PVE и PVP, но те кто мог использовали Outfitter для быстрой смены экипировки. И вот начиная с патча 3.1.2, Близзард решили сделать свой Outfitter и назвали его \\\\\\\"Управление экипировкой\\\\\\\".<br /> <br /> <strong><span>FloTotemBar</span></strong> - Излюбленный аддон для шаманов ровно до патча 3.x, точно не помню в каком именно патче разработчики игры решили позаимствовать идею отдельных панелей для тотемов. Теперь использовать Тотем бар будут наверно только те, кому не нравиться стандартный интерфейс.<br /> <br /> <strong><span>VuhDo</span></strong> - Изменял интерфейс рейд-иконок. и позволял лечащим классам чувствовать себя увереннее.<br /> <br /> <strong><strong><span>Grid </span></strong></strong>- Так же как и VuhDo аддон был полностью перенесен в интерфейс игры разработчиками, начиная с патча 4.0.1. Поэтому в Катаклизме у этих двух аддонов перспективы на существование нету.<br /> <br /> Group Calendar - Аддон прижился далеко не во всех гильдиях, ибо заставить всех установить его было не легкой задачей. Теперь в этом нет необходимости, так как календарь появился по умолчанию.<br /> <br /> AVR - Помогал организовать рейды, в плане управления толпой. Некоторые рейды без этого аддона были бы просто большим бестолковым пати. Но до катаклизма аддон не дожил ибо Близы официально его запретили, а в катаклизме сделали свою, более простую и красивую версию данного аддона.<br /> <br /> EquipCompare - Как сравнить шмотку надетую на вас, с той что в инвентаре или магазине? Ну естественно надо нажать кнопку Shift, но ранее такой опции в игре не было, и для этого был придуман EquipCompare. После выхода WotLK про аддон забыли, но его по прежнему разрабатывают.<br /> <br /> Buff Timers - Отличная модификация иконок Бафов, времен Пылающего Легиона. Аддон добавлял таймеры возле картинок бафов или дебафов, что позволяло узнать когда он спадет. Удивительно как Близард сразу не додумались такое интегрировать в интерфейс? Теперь в этом аддоне нет нужды, по понятным всем причинам.<br /> <br /> Не смотря на то, что в свое время Близард даже пытались запретить донат за аддоны, которые созданы сторонними разработчиками для улучшения игры, и делают ее интереснее. В сети все ровно появляются все новые и новые модификации, и как бы Близард не бесилась по этому поводу, прогресс не остановить, как и тот факт что весь прогресс будет в итоге присвоен \\\\\\\"Конторой\\\\\\\".</p>', '-1', '0');
INSERT INTO `wcf_news_cats` VALUES ('1', 'Новости', 'news.gif');
INSERT INTO `wcf_news_cats` VALUES ('2', 'Ошибки', 'bugs.gif');
INSERT INTO `wcf_news_cats` VALUES ('3', 'Игры', 'games.gif');
INSERT INTO `wcf_news_cats` VALUES ('4', 'Интернет', 'network.gif');
INSERT INTO `wcf_news_cats` VALUES ('5', 'Загрузки', 'downloads.gif');
INSERT INTO `wcf_news_cats` VALUES ('6', 'БСД', 'bsd.gif');
INSERT INTO `wcf_news_cats` VALUES ('7', 'Графика', 'graphics.gif');
INSERT INTO `wcf_news_cats` VALUES ('8', 'Аппаратные средства', 'hardware.gif');
INSERT INTO `wcf_news_cats` VALUES ('9', 'Журнал', 'journal.gif');
INSERT INTO `wcf_news_cats` VALUES ('10', 'Linux', 'linux.gif');
INSERT INTO `wcf_news_cats` VALUES ('11', 'Мас', 'mac.gif');
INSERT INTO `wcf_news_cats` VALUES ('12', 'Пользователи', 'members.gif');
INSERT INTO `wcf_news_cats` VALUES ('13', 'Моды', 'mods.gif');
INSERT INTO `wcf_news_cats` VALUES ('14', 'Видео', 'movies.gif');
INSERT INTO `wcf_news_cats` VALUES ('15', 'Музыка', 'music.gif');
INSERT INTO `wcf_news_cats` VALUES ('16', 'Безопасность', 'security.gif');
INSERT INTO `wcf_news_cats` VALUES ('17', 'Программы', 'software.gif');
INSERT INTO `wcf_news_cats` VALUES ('18', 'Схемы Скины', 'themes.gif');
INSERT INTO `wcf_news_cats` VALUES ('19', 'Web Clear Fusion', 'web-clear-fusion.gif');
INSERT INTO `wcf_news_cats` VALUES ('20', 'Виндовс', 'windows.gif');
INSERT INTO `wcf_settings` VALUES ('servername', 'Name WoW Server');
INSERT INTO `wcf_settings` VALUES ('serverurl', '/');
INSERT INTO `wcf_settings` VALUES ('serverbanner', 'images/banners.png');
INSERT INTO `wcf_settings` VALUES ('serverintro', '<div style=\\\'text-align:center\\\'>Добро пожаловать на сайт!<br>Наш set realmlist WoW Server</div>');
INSERT INTO `wcf_settings` VALUES ('opening_page', 'news.php');
INSERT INTO `wcf_settings` VALUES ('lang', 'russian');
INSERT INTO `wcf_settings` VALUES ('theme', 'default');
INSERT INTO `wcf_settings` VALUES ('exclude_left', '');
INSERT INTO `wcf_settings` VALUES ('exclude_right', '');
INSERT INTO `wcf_settings` VALUES ('exclude_upper', '');
INSERT INTO `wcf_settings` VALUES ('exclude_lower', '');
INSERT INTO `wcf_settings` VALUES ('kcaptcha_enable_auth', '0');
INSERT INTO `wcf_settings` VALUES ('page_forum_threads', '10');
INSERT INTO `wcf_settings` VALUES ('page_forum_posts', '10');
INSERT INTO `wcf_settings` VALUES ('pass_remember', 'on');
INSERT INTO `wcf_settings` VALUES ('registration_ip_limit', '0');
INSERT INTO `wcf_settings` VALUES ('page_news', '5');
INSERT INTO `wcf_settings` VALUES ('page_online', '30');
INSERT INTO `wcf_settings` VALUES ('license_agreement', 'Регистрация учётной записи для игры в WoW на нашем сервере. Внимательно, правильно заполните все поля этой формы. Особое внимание обращаем на правильность ввода E-mailа, т.к. многие операции с учётными записями и персонажами требуют подтверждения по электронной почте. Имя учётной записи и пароль не должны совпадать.<hr>Большая просьба не регистрировать учётные записи, содержащие русские буквы, а то вы не сможете правильно подключиться к серверу.<hr> Удачной вам игры. Спасибо за внимание.<br>');
INSERT INTO `wcf_settings` VALUES ('permit_registration', '1');
INSERT INTO `wcf_settings` VALUES ('level_administration', '2');
INSERT INTO `wcf_users` VALUES ('1', 'ADMINISTRATOR', 'a34b29541b87b7e4823683ce6c7bf6ae68beaaac', '3', null, '', '0.0.0.0', '0');
INSERT INTO `wcf_users` VALUES ('2', 'GAMEMASTER', '7841e21831d7c6bc0b57fbe7151eb82bd65ea1f9', '2', null, '', '0.0.0.0', '0');
INSERT INTO `wcf_users` VALUES ('3', 'MODERATOR', 'a7f5fbff0b4eec2d6b6e78e38e8312e64d700008', '1', null, '', '0.0.0.0', '0');
INSERT INTO `wcf_users` VALUES ('4', 'PLAYER', '3ce8a96d17c5ae88a30681024e86279f1a38c041', '0', null, '', '0.0.0.0', '0');
INSERT INTO `wcf_users` VALUES ('5', 'LOVEPSONE', '549fad275db9cb8458e3bc14575684d7a38a3c72', '3', null, '', '0.0.0.0', '0');