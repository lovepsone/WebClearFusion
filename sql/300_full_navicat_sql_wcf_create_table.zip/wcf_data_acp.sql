/*
MySQL Data Transfer
Source Host: localhost
Source Database: wcf
Target Host: localhost
Target Database: wcf
Date: 14.03.2012 16:04:30
*/

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `wcf_acp_panels` VALUES ('1', 'navigation_panel_acp', 'file', '0', '1', '1', '1', '0');
INSERT INTO `wcf_acp_panels` VALUES ('2', 'user_or_server_panel_acp', 'file', '0', '4', '2', '1', '0');
